import numpy as np
import argparse
import os 


def get_binomial(n, m, p):
    return np.math.factorial(n) / (np.math.factorial(n-m) * np.math.factorial(m)) * np.power(p, m) * np.power(1.0-p, n-m)


def beta_binomial(a, b, outcome):
    for i, x in enumerate(outcome):
        ones = x.count('1')
        zeros = x.count('0')
        
        prob = float(ones) / (ones + zeros)
        
        likelihood = get_binomial(len(x), ones, prob)
        
        posterior_a = a + ones
        posterior_b = b + zeros
        
        print(f'case {i + 1}: {x}')
        print(f'Likelihood: {likelihood}')
        print(f'Beta prior:\ta= {a}\tb= {b}')
        print(f'Beta posterior:\ta= {posterior_a}\tb= {posterior_b}')
        
        a = posterior_a
        b = posterior_b
        

def parse_arguments():
    parser = argparse.ArgumentParser(description='HW2 Naive Bayes Classifier')
    parser.add_argument('--a', default=0, type=int)
    parser.add_argument('--b', default=0, type=int)
    return parser.parse_args()        
        
if __name__ == '__main__':
    args = parse_arguments()
    a = args.a
    b = args.b
    
    ### load data
    with open("." + os.sep + "textfile.txt", 'r') as f:
        data = f.read().splitlines() 
        
    beta_binomial(a, b, data)